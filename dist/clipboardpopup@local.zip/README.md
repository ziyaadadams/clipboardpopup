# Clipboard Popup (GNOME Shell Extension)

Windows-style clipboard history invoked by a shortcut (default: Super+V). Shows a popup near the pointer with recent entries; selecting an item copies it (and optionally auto-pastes on X11 with xdotool installed). Captures text and images (PNG, up to ~1.5 MB).

Supports GNOME Shell 45–49.

## Quick start
1) Compile schemas (required after edits):
   ```sh
   glib-compile-schemas schemas/
   ```
2) Link or copy into your extensions directory:
   ```sh
   EXT_DIR="$HOME/.local/share/gnome-shell/extensions/clipboardpopup@local"
   mkdir -p "$EXT_DIR"
   cp -r * "$EXT_DIR"
   ```
3) (Optional) Build zip: `./build.sh` (outputs dist/clipboardpopup@local.zip).
4) Restart GNOME Shell (Alt+F2, type `r`, Enter on X11; or log out/in on Wayland).
5) Enable the extension via `gnome-extensions enable clipboardpopup@local` or Extensions app.

## Features implemented now
- Shortcut-triggered popup (default `<Super>v`, configurable via gsettings).
- Clipboard text history with configurable size and persistence under `~/.cache/clipboardpopup/history.json`.
- Pinned items respected during pruning; inline pin buttons; keyboard pin/unpin (Ctrl+P) and delete (Delete key) when popup is focused; clear-unpinned confirmation and unpin-all controls.
- Popup near pointer, keyboard and mouse selection; Enter activates, Esc closes; Up/Down to navigate; inline search filter; positions within the active monitor.
- Captures text and images (PNG). Image entries show dimensions and a thumbnail; size-limited to ~1.5 MB to avoid bloat.
- Captures source app metadata (when available) and displays it alongside timestamps.
- Copies selection to both CLIPBOARD and PRIMARY; optional auto-paste on X11 if `xdotool` is available.
- Optional tracking of PRIMARY selection (toggle `track-primary`).
- Paste plain text: Shift+Enter forces plain text; optional default via setting/prefs.
- Right-click an entry to paste plain text; Enter pastes rich when available.
- Emoji/symbols picker with search; selection inserts into history and clipboard.
- Rich text: stores HTML and RTF alongside plain text when the provider offers them; pastes rich (HTML, then RTF) when available unless plain-text mode is chosen.
- Pause capture toggle and secure-context heuristics with a skip list to avoid capturing sensitive windows.

## Settings (gschema)
- `history-size` (int): max entries (pinned items are always kept).
- `poll-interval-ms` (int): polling interval for clipboard changes.
- `shortcut` (string): keybinding, e.g., `<Super>v`.
- `persist-history` (bool): save history to disk.
- `track-primary` (bool): also record PRIMARY selections (mostly X11).
- `auto-paste` (bool): try to auto-paste after selection (X11 + xdotool only).
- `paste-as-plain-text` (bool): strip formatting when pasting; Shift+Enter forces plain text even if disabled.
- `pause-capture` (bool): stop recording clipboard changes.
- `enable-secure-heuristics` (bool): skip capture for known/blocked windows.
- `skip-wm-classes` (strv): window classes to always skip.
- `max-rich-bytes` (int): cap for stored HTML/RTF payloads to avoid bloat.

Use the preferences dialog (Extensions app → gear) to adjust these; the shortcut entry is plain text (e.g., `<Super>v`, `<Alt>v`).

## Notes / Wayland
Wayland disallows injecting key events; auto-paste cannot be provided there. Selection still copies to clipboard; press Ctrl+V yourself to paste.

## Next steps
- Richer rendering (formatted snippets), emojis/symbols parity.
- Smarter dedupe/merge and clipboard source labeling (improve reliability on Wayland).
- Visual polish and accessibility tweaks (ARIA labels, focus ring, spacing).

## Testing
See [TESTING.md](TESTING.md) for a manual smoke/regression checklist.

## Packaging
- Build zip: `./build.sh`
- Validate and build in one go: `./check.sh` (requires `glib-compile-schemas`; optionally `gnome-extensions` for validation)
